package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val username = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        val loginbtn = findViewById<Button>(R.id.loginbtn)
        val txtNextFrame = findViewById<TextView>(R.id.txt_next_frame)

        loginbtn.setOnClickListener {
            // Do something when login button is clicked
            // e.g. check user input, perform login request, etc.
        }
        txtNextFrame.setOnClickListener {
            startActivity(intent)
            // Create an Intent to start another activity
            val intent = Intent(this, RegistrasiActivity::class.java)
            startActivity(intent)

        }
        val Button = findViewById<Button>(R.id.loginbtn)
        loginbtn.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)

        }
    }
}







   
