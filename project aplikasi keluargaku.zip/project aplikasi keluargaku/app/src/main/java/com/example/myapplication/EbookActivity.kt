package com.example.myapplication

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class EbookActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ebook)

        val Ebook = findViewById<TextView>(R.id.Ebook)
        val button = findViewById<Button>(R.id.kembali3)


        val textView: TextView = findViewById(R.id.Ebook)
        Ebook.setOnClickListener {
            val openURL = Intent(Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://keluargaku.or.id/ebook")
            startActivity(openURL)

        }
        val Button = findViewById<Button>(R.id.kembali3)
        Button.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
        }
    }
}