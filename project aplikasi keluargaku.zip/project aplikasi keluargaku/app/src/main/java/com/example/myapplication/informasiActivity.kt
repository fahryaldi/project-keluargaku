package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class informasiActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_informasi)

        val bg1 = findViewById<ImageView>(R.id.bg1)
        val bg2 = findViewById<ImageView>(R.id.bg2)
        val linkinformasi = findViewById<TextView>(R.id.linkinformasi)
        val kembali = findViewById<Button>(R.id.kembali)

        val linkInformasi: TextView = findViewById(R.id.linkinformasi)
        linkInformasi.setOnClickListener{
            val openURL = Intent(Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://www.bkkbn.go.id/#")
            startActivity(openURL)

        }
        val Button = findViewById<Button>(R.id.kembali)
        kembali.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
        }
    }
}