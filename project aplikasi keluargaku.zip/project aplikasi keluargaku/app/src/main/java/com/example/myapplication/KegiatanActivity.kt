package com.example.myapplication

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class KegiatanActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kegiatan)

        val textView = findViewById<TextView>(R.id.linkkegiatan)
        val button = findViewById<Button>(R.id.kembali2)


        val linkkegiatan: TextView = findViewById(R.id.linkkegiatan)
        linkkegiatan.setOnClickListener {
            val openURL = Intent(Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://keluargaku.or.id/kegiatan")
            startActivity(openURL)
        }
        val Button = findViewById<Button>(R.id.kembali)
        Button.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
            }

    }
}