package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton


class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val imginformasi = findViewById<ImageButton>(R.id.imginformasi)
        val imgkegiatan = findViewById<ImageButton>(R.id.imgkegiatan)
        val imgbuku = findViewById<ImageButton>(R.id.imgbuku)
        val imgvideo = findViewById<ImageButton>(R.id.imgvideo)
        val imgkonselor = findViewById<ImageButton>(R.id.imgkonselor)

        imginformasi.setOnClickListener {
            val intent = Intent(this, informasiActivity::class.java)
            startActivity(intent)
        }

        imgkegiatan.setOnClickListener {
            val intent = Intent(this, KegiatanActivity::class.java)
            startActivity(intent)
        }

        imgbuku.setOnClickListener {
            val intent = Intent(this, EbookActivity::class.java)
            startActivity(intent)
        }
  }

    }


